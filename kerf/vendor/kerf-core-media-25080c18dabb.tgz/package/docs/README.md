# Kerf reference

These are the pages `npx kerf docs <topic>` prints, shipped with `@kerf-js/core` so they can be read offline.
The same pages are on GitHub: https://github.com/Ravonus/kerf/tree/main/packages/cli/docs

| Page | Topic |
| --- | --- |
| [async.md](./async.md) | Async data, Boundary and SSR |
| [browser.md](./browser.md) | Browser values (`@kerf-js/core/browser`) |
| [config.md](./config.md) | kerf.config |
| [core.md](./core.md) | Core entrypoints |
| [deploy.md](./deploy.md) | Deploy: from `kerf build` to a live URL |
| [design.md](./design.md) | Design: tokens, primitives, D-codes |
| [entrypoints.md](./entrypoints.md) | Core and Start entrypoints |
| [fonts.md](./fonts.md) | Fonts |
| [icons.md](./icons.md) | Icons |
| [lists.md](./lists.md) | Lists and conditionals |
| [media.md](./media.md) | Media delivery and original-file saving |
| [meta.md](./meta.md) | Page metadata and share cards |
| [plugins.md](./plugins.md) | How pay is built |
| [props.md](./props.md) | Props |
| [reactivity.md](./reactivity.md) | Reading reactive values |
| [rules.md](./rules.md) | rules |
| [rust.md](./rust.md) | Rust: `native()` and `remote()` |
| [start-short.md](./start-short.md) | start-short |
| [start.md](./start.md) | Full stack: `@kerf-js/start` |
| [state.md](./state.md) | State (`@kerf-js/core`) |
| [style.md](./style.md) | Styling: style groups |
| [surface.md](./surface.md) | Surfaces (`@kerf-js/core/surface`) |
| [testing.md](./testing.md) | Testing (`@kerf-js/core/test`, vitest) |
| [theme.md](./theme.md) | Theme: changing veneer's look |
| [ui-state.md](./ui-state.md) | Shared UI state |
| [verify.md](./verify.md) | Verify your work |
