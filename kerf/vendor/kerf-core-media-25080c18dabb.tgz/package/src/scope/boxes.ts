import { DEV, rt } from '../index/graph'
import type { Box } from '../index/state'
import type { App, Instance, features, owners, StateError } from '../scope'

type Deps = {
  inst: Instance
  boxes: Box<unknown>[]
  named: Map<Box<unknown>, string>
  app: App
  def: { name: string }
  features: typeof features
  owners: typeof owners
  onWrite: (box: Box<unknown>, before: unknown) => void
  StateError: typeof StateError
}

export function attachBoxes({
  inst,
  boxes,
  named,
  app,
  def,
  features,
  owners,
  onWrite,
  StateError,
}: Deps) {
  const seed = app.seed[def.name] ?? rt.state?.[def.name] ?? {}
  if (rt.state) delete rt.state[def.name]
  for (const box of boxes) {
    const name = box.opts?.name ?? named.get(box)
    if (DEV) box.n = `${def.name}.${name ?? '#'}`
    inst.inits.set(box, box.v)
    owners.set(box, inst)
    if (box.opts?.persist) {
      if (DEV && !features.persist)
        throw new StateError(
          'S008',
          `\`${def.name}\` persists a box, but @kerf-js/core/persist isn't loaded`,
          "the kerf() Vite plugin adds it; without the plugin, `import '@kerf-js/core/persist'`",
        )
      if (DEV && !name)
        throw new StateError(
          'S008',
          `\`${def.name}\` persists a box it doesn't return or name`,
          "return it from the setup, or give it `name: '…'`",
        )
      features.persist!.load(inst, box, name!)
    }
    if (name && name in seed) box.v = seed[name] // before setup returns: nothing has read it yet
    if (box.opts?.sync) {
      if (DEV && !features.sync)
        throw new StateError(
          'S008',
          `\`${def.name}\` syncs a box, but @kerf-js/core/sync isn't loaded`,
          "the kerf() Vite plugin adds it; without the plugin, `import '@kerf-js/core/sync'`",
        )
      if (DEV && !name)
        throw new StateError(
          'S008',
          `\`${def.name}\` syncs a box it doesn't return or name`,
          "return it from the setup, or give it `name: '…'`",
        )
      features.sync!.attach(inst, box, name!)
    }
    box.h = onWrite
  }
}
