// `scroller`: puts the engine, its inputs and its bars on a root element. `scroller-api.ts` is what it returns.
import { autoscroll } from './autoscroll'
import { barInput } from './bar-input'
import { Engine, reduceQuery, registry } from './engine'
import { keyInput } from './keys'
import { resolve, writeVars } from './options'
import { domRenderer, drawBars, mountBars, Visibility } from './render'
import { api } from './scroller-api'
import { touchInput } from './touch'
import { wheelInput } from './wheel-input'
import type { Renderer, ScrollOptions, Scroller } from './types'

const FOCUSABLE =
  'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"]),[contenteditable]:not([contenteditable="false"]),summary,iframe,audio[controls],video[controls]'

/** What the setup steps share. */
export interface Setup {
  e: Engine
  vis: Visibility
  options: ScrollOptions
  renderer: Renderer
  remeasure: () => void
  /** Rebuild the bars, for a change of axes. */
  rebar: () => void
  /** Attach the inputs again, for a change of mode. */
  reinput: () => void
}

/**
 * Custom scrolling on `root`, which holds a `[data-part="viewport"]` element (and, inside that, the content). In the
 * default `native` mode the browser scrolls the viewport, with its own bars hidden, and this draws the bars; in
 * `engine` mode the viewport is `overflow: hidden` and every input runs here. Either way it keeps real scroll offsets,
 * so focus, find, anchors and `scroll` listeners still work. Bars are found as `[data-part="scrollbar"]
 * [data-orientation]` children of `root`, or made. Load `@kerf-js/scroll/styles.css`.
 */
export function scroller(root: HTMLElement, options: ScrollOptions = {}): Scroller {
  const vp = root.querySelector<HTMLElement>(':scope > [data-part="viewport"]') ?? root
  registry
    .get(vp)
    ?.destroyHooks.splice(0)
    .forEach((f) => f())
  const content = vp === root ? null : (vp.firstElementChild as HTMLElement | null)
  const e = new Engine(root, vp, content, resolve(options))
  const vis = new Visibility(e)
  const hooks = e.destroyHooks
  const tabStop = focusable(vp, hooks)
  // Reads happen in one place (measure, from the ResizeObserver batch) and writes in the frame, so a page that mounts
  // many scrollers lays out once, not once per scroller.
  let stale = true
  const s: Setup = {
    e,
    vis,
    options,
    renderer: e.o.renderer ?? domRenderer,
    remeasure: () => {
      e.measure()
      stale = true
      e.wake()
    },
    rebar: () => {},
    reinput: () => {},
  }
  vp.setAttribute('data-scroll-viewport', '')
  configure(s)
  tabStop()
  let unbar = mountBars(e, () => s.renderer)
  hooks.push(() => unbar())
  root.toggleAttribute('data-ready', true)
  if (typeof ResizeObserver !== 'function') e.measure()
  e.onActivity = () => vis.moved()
  e.onFrame = (now) => {
    if (stale && e.measured) {
      stale = false
      tabStop()
      vis.apply()
    }
    return drawBars(e, s.renderer, e.last ? now - e.last : 16)
  }
  const watching = watch(s)
  s.rebar = () => {
    unbar()
    unbar = mountBars(e, () => s.renderer)
    barsOff()
    barsOff = barInput(e, vis)
    watching.observe()
    s.remeasure()
  }
  hooks.push(watching.stop, listen(s))
  let barsOff = barInput(e, vis)
  let inputsOff = inputs(e)
  s.reinput = () => {
    inputsOff()
    inputsOff = inputs(e)
  }
  hooks.push(
    () => inputsOff(),
    () => barsOff(),
  )
  hooks.push(() => {
    vis.destroy()
    if (e.frame) cancelAnimationFrame(e.frame)
    if (e.content) e.content.style.transform = ''
    for (const name of ['data-ready', 'data-timeline', 'data-mode', 'data-chain'])
      root.removeAttribute(name)
    vp.removeAttribute('data-scroll-viewport')
    registry.delete(vp)
  })
  registry.set(vp, e)
  e.wake()
  return api(s, () => configure(s))
}

/**
 * The engine's input. In native mode even a wheel or touch listener that does nothing would cost the compositor its
 * scrolling, so only keys (which reach the page first in any case, and which some browsers don't scroll a focused
 * area for) and a mouse `grab` are attached.
 */
function inputs(e: Engine) {
  const native = e.o.mode === 'native'
  const offs = native
    ? [keyInput(e), e.o.grab ? touchInput(e) : () => {}]
    : [wheelInput(e), keyInput(e), touchInput(e), autoscroll(e)]
  return () => offs.forEach((f) => f())
}

let timelines: boolean | undefined
/** Whether CSS can drive the thumbs from the viewport's scroll position, as a named, scoped scroll timeline. */
const canTimeline = () =>
  (timelines ??=
    typeof CSS !== 'undefined' &&
    CSS.supports('animation-timeline: --a') &&
    CSS.supports('timeline-scope: --a'))

/** Options into attributes and custom properties on the root and viewport. */
function configure({ e, options, renderer }: Setup) {
  const { root, vp } = e
  root.dataset.mode = e.o.mode
  root.dataset.chain = e.o.chain
  const timeline = e.o.mode === 'native' && renderer === domRenderer && canTimeline()
  if (timeline !== e.timeline) for (const a of e.axes) a.drawn = ''
  e.timeline = timeline
  root.toggleAttribute('data-timeline', timeline)
  e.ax.y.on = e.o.axes !== 'x'
  e.ax.x.on = e.o.axes !== 'y'
  root.dataset.scroll ??= ''
  root.dataset.layout = e.o.bar.layout
  root.dataset.show = e.o.bar.show
  root.dataset.axes = e.o.axes
  vp.dataset.touch = e.o.touch
  writeVars(root, options.bar, e.reduced())
  if (e.o.label) {
    vp.setAttribute('role', 'region')
    vp.setAttribute('aria-label', e.o.label)
  }
}

/**
 * As browsers treat scrollers: a tab stop only when nothing inside can take focus, and always focusable by a click so
 * the keys work after one. Returns the check, to run again when the content changes.
 */
function focusable(vp: HTMLElement, hooks: (() => void)[]) {
  if (vp.hasAttribute('tabindex')) return () => {}
  hooks.push(() => vp.removeAttribute('tabindex'))
  return () => {
    vp.tabIndex = vp.querySelector(FOCUSABLE) ? -1 : 0
  }
}

/** Measure again when the viewport, the content or a bar changes size, or the content is swapped. */
function watch(s: Setup) {
  const { e } = s
  const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(() => s.remeasure()) : null
  const observe = () => {
    ro?.disconnect()
    ro?.observe(e.vp)
    if (e.content) ro?.observe(e.content)
    for (const a of e.axes) if (a.track) ro?.observe(a.track)
  }
  observe()
  const mo =
    typeof MutationObserver === 'function' && e.vp !== e.root
      ? new MutationObserver(() => {
          const next = e.vp.firstElementChild as HTMLElement | null
          if (next === e.content) return
          e.content = next
          observe()
          s.remeasure()
        })
      : null
  mo?.observe(e.vp, { childList: true })
  return {
    observe,
    stop: () => {
      ro?.disconnect()
      mo?.disconnect()
    },
  }
}

/** The browser's own scrolling, the pointer over the area, and the reduced-motion setting. */
function listen({ e, vis, options }: Setup) {
  let idle: ReturnType<typeof setTimeout> | undefined
  // In native mode the browser's scroll has ended: rest on a snap point, as the engine does after its own input.
  const settle = () => {
    if (e.o.mode !== 'native') return
    for (const a of e.axes) {
      a.v = 0
      e.settle(a.axis)
    }
  }
  const ends = typeof window !== 'undefined' && 'onscrollend' in window
  const onNative = () => {
    if (e.dispatching) return
    e.adopt()
    if (ends) return
    clearTimeout(idle)
    idle = setTimeout(settle, 150)
  }
  const inside = (on: boolean) => () => {
    vis.inside = on
    vis.apply()
  }
  const enter = inside(true)
  const leave = inside(false)
  const motion = reduceQuery()
  const onMotion = () => writeVars(e.root, options.bar, e.reduced())
  e.vp.addEventListener('scroll', onNative, { passive: true })
  e.vp.addEventListener('scrollend', settle)
  e.root.addEventListener('pointerenter', enter)
  e.root.addEventListener('pointerleave', leave)
  motion?.addEventListener?.('change', onMotion)
  return () => {
    clearTimeout(idle)
    e.vp.removeEventListener('scroll', onNative)
    e.vp.removeEventListener('scrollend', settle)
    e.root.removeEventListener('pointerenter', enter)
    e.root.removeEventListener('pointerleave', leave)
    motion?.removeEventListener?.('change', onMotion)
  }
}
