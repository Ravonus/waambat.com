// @kerf-js/veneer-core: veneer without a framework. The spec CSS (styles/, split per component) and the behaviour as plain TS
// over the DOM: actions shaped (el, opts) => { update, destroy }, small stores for stateful widgets, and the pure
// helpers a binding needs to render the specimen markup. Nothing here imports a framework (test/agnostic.test.mjs);
// the kerf binding is its own subpath, `@kerf-js/veneer-core/kerf`.
export { store, uid, resetIds, type Store, type Action } from './store'
export { installSweep, sweep, type SweepMachine } from './sweep'
export { pressOrigin } from './press-origin'
export { flow } from './flow'
export { field, floatingLabel, labelChars } from './floating-label'
export {
  buildIndex,
  openIndex,
  searchIndex,
  fuzzyIndex,
  words,
  type SearchEntry,
  type SearchHit,
  type SearchIndex,
  type SearchWire,
} from './search'
export {
  DIALS,
  getDial,
  setDial,
  setPalette,
  getPalette,
  dialsFromUrl,
  type Dial,
  type DialValue,
} from './dial'
export { nextIndex, roving, anchor, type Orientation, type Placement } from './focus'
export {
  pushLayer,
  onTopModal,
  place,
  justEscaped,
  type Layer,
  type Side,
  type Align,
} from './layers'
export { dialog, popover, tooltip, type DialogOptions, type PopoverOptions } from './overlays'
export { sheet, type Detent, type SheetOptions } from './sheet'
export { isMobileDevice, markDevice } from './device'
export { edges, indicator, overflow, type IndicatorOptions } from './indicator'
export { moveShuttle, type Across } from './shuttle'
export { listbox, type ListboxOptions, type ListItem } from './listbox'
export { slider, type SliderOptions } from './slider'
export { formInvalid, formReset, reportMissing } from './form'
export {
  toastStore,
  toaster,
  announce,
  lifeOf,
  type Toast,
  type ToastInput,
  type ToastPromise,
  type ToastStore,
  type Tone,
} from './toast'
export {
  TYPE_SCALE,
  FLUID_RANGE,
  MAX_FLUID_RATIO,
  fluid,
  fluidRatio,
  fluidCss,
  type Fluid,
  type FluidRole,
  type Stop,
} from './type'
export {
  skeletonShape,
  isPart,
  type ShapeKind,
  type ShapeSpec,
  type SkeletonPart,
  type SkeletonBox,
} from './shape'
export { menu, type MenuOptions } from './menu'
export { shell, type ShellOptions } from './shell'
export {
  table,
  compareValues,
  sortRows,
  filterRows,
  pageSlice,
  rangeOf,
  checkState,
  hideRule,
  type TableOptions,
  type SortDir,
} from './table'
export {
  Sizes,
  virtualizer,
  slices,
  type Virtualizer,
  type VirtualOptions,
  type VirtualKey,
  type VirtualAlign,
} from './virtual'
export * from './temporal'
export * from './segments'
export * from './calendar'
export {
  isSheet,
  pickerPanel,
  comboPopup,
  listKey,
  defaultPresets,
  type PanelOptions,
  type Presentation,
  type RangePreset,
} from './picker'
export * from './recurrence'
export * from './identity'
export * from './signature'
export * from './agent'
export * from './schedule'
export * from './live'
export * from './collab'
export * from './flow-pack'
export * from './admin'
export {
  pageList,
  infiniteScroll,
  matchFilter,
  groupRows,
  aggregate,
  treeRows,
  leaves,
  pivotTable,
  toTSV,
  parseTSV,
  toCSV,
  moved,
  grid,
  type GridFilter,
  type GridOptions,
  type Aggregate,
  type TreeEntry,
  type TreeSource,
  type PivotCell,
} from './grid'
export {
  fuzzy,
  matchStrength,
  rankCommands,
  marked,
  paletteHotkey,
  type Rankable,
  type Ranked,
} from './palette'
export {
  mentionToken,
  parseMentions,
  serializeMentions,
  shiftMarks,
  findTrigger,
  caretPoint,
  type MentionItem,
  type MentionMark,
} from './mention'
export { copyButtons } from './copy'
export {
  indented,
  tokenize,
  highlight,
  jsonProblem,
  codeLayer,
  type CodeToken,
  type CodeSpan,
} from './code'
export {
  sanitizeHtml,
  safeUrl,
  markdownToHtml,
  htmlToMarkdown,
  richText,
  keyboardDock,
  type RichTextOptions,
  type RichTextHandle,
} from './editor'
export { navIndicator, type NavIndicatorOptions } from './nav'
export {
  readCollapsed,
  readFolds,
  sideNav,
  writeCollapsed,
  writeFolds,
  type Folds,
  type SideNavOptions,
} from './sidenav'
export { interact, type Flag, type Interactive } from './interact'

export { scrollPage } from './page-scroll'
